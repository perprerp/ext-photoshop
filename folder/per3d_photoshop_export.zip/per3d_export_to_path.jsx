﻿#include per3d_exporter.jsxinc

//===========================================================================
// per3d Photoshop Exporter
// For Adobe Photoshop CC 2017
// By Per Abrahamsen
// per@per3d.biz
// 
//   Please see "per3d_photoshop_exporter.txt" for complete documentation.
//===========================================================================

PER3D_export ( null, "/c/mygame/assets/shoes");
